// src/utils/database.js
const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "your_db_user",
  password: "your_db_password",
  database: "user_auth_db",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL:", err);
  } else {
    console.log("Connected to MySQL database");
  }
});

module.exports = {
  query: (sql, values) => {
    return new Promise((resolve, reject) => {
      db.query(sql, values, (err, results) => {
        if (err) {
          return reject(err);
        }
        resolve(results);
      });
    });
  },
};
